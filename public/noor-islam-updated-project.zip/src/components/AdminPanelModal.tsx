import React, { useState } from 'react';
import { useAuth, ADMIN_EMAILS } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  X,
  ShieldCheck,
  Users,
  Video,
  BookOpen,
  MapPin,
  Calendar,
  HeartHandshake,
  AlertTriangle,
  GraduationCap,
  Settings,
  Lock,
  CheckCircle2,
  Download,
  Upload,
  Server,
  Key,
  Database,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const [activeAdminTab, setActiveAdminTab] = useState<string>('owner');
  const [backupMessage, setBackupMessage] = useState<string>('');

  if (!isOpen) return null;

  const adminTabs = [
    { id: 'owner', label: language === 'en' ? 'Owner Control & Infrastructure' : 'مالکانہ کنٹرول و سیکیورٹی', icon: ShieldCheck },
    { id: 'overview', label: language === 'en' ? 'System Overview' : 'نظام کا جائزہ', icon: Server },
    { id: 'moderation', label: language === 'en' ? '3-Warning Log' : '۳ وارننگ ماڈریشن', icon: AlertTriangle },
    { id: 'teachers', label: language === 'en' ? 'Teacher Vetting' : 'اساتذہ کی جانچ', icon: GraduationCap },
    { id: 'charity', label: language === 'en' ? 'Charity Audit' : 'خدمتِ خلق آڈٹ', icon: HeartHandshake }
  ];

  // Backup exporter
  const handleExportBackup = () => {
    try {
      const backupData = {
        app: 'Hasan Quran',
        version: '1.0.0',
        timestamp: new Date().toISOString(),
        ownerAccount: 'alihusnain03221704751@gmail.com',
        userPreferences: user?.preferences || {},
        bookmarks: {
          quranBookmarks: localStorage.getItem('noor_quran_bookmarks') || '[]',
          mushaf16LineBookmarks: localStorage.getItem('noor_16line_bookmarks') || '[]',
          last16LinePage: localStorage.getItem('noor_16line_last_page') || '1'
        },
        prayerSettings: {
          selectedCity: localStorage.getItem('noor_selected_city') || '{}',
          prayerAlerts: localStorage.getItem('noor_prayer_alerts') || '{}',
          soundEnabled: localStorage.getItem('noor_sound_enabled') || 'true',
          azanVoice: localStorage.getItem('noor_azan_voice') || 'makkah'
        },
        tasbeehTotal: localStorage.getItem('noor_tasbeeh_total') || '0',
        futureInterest: localStorage.getItem('noor_future_feature_interest') || '[]'
      };

      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `hasan_quran_app_backup_${new Date().toISOString().slice(0, 10)}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();

      setBackupMessage(language === 'en' ? 'System backup downloaded successfully!' : 'بیک اپ فائل کامیابی سے ڈاؤنلوڈ ہو گئی!');
      setTimeout(() => setBackupMessage(''), 4000);
    } catch (err) {
      setBackupMessage(language === 'en' ? 'Backup generation failed.' : 'بیک اپ تیار کرنے میں خرابی ہوئی۔');
    }
  };

  // Backup importer
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);

        if (parsed.app === 'Hasan Quran' || parsed.app === 'Noor Islam' || parsed.app === 'Noor Islamic App') {
          if (parsed.bookmarks?.quranBookmarks) {
            localStorage.setItem('noor_quran_bookmarks', parsed.bookmarks.quranBookmarks);
          }
          if (parsed.bookmarks?.mushaf16LineBookmarks) {
            localStorage.setItem('noor_16line_bookmarks', parsed.bookmarks.mushaf16LineBookmarks);
          }
          if (parsed.prayerSettings?.prayerAlerts) {
            localStorage.setItem('noor_prayer_alerts', parsed.prayerSettings.prayerAlerts);
          }
          if (parsed.prayerSettings?.selectedCity) {
            localStorage.setItem('noor_selected_city', parsed.prayerSettings.selectedCity);
          }
          setBackupMessage(language === 'en' ? 'Backup restored successfully! Refreshing...' : 'بیک اپ ڈیٹا بحال ہو گیا!');
          setTimeout(() => window.location.reload(), 1500);
        } else {
          setBackupMessage(language === 'en' ? 'Invalid backup file format.' : 'غلط بیک اپ فارمیٹ۔');
        }
      } catch {
        setBackupMessage(language === 'en' ? 'Failed to read backup file.' : 'فائل پڑھنے میں ناکامی۔');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-stone-200 overflow-hidden text-stone-800 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-stone-900 text-stone-100 p-6 flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-amber-300">
                  {language === 'en' ? 'Owner Control Center & Admin Panel' : 'ایڈمن اور مالکانہ کنٹرول سینٹر'}
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-900 text-emerald-300 border border-emerald-700">
                  SUPER ADMIN RBAC
                </span>
              </div>
              <p className="text-xs text-stone-400">
                {language === 'en'
                  ? 'Exclusive administrative governance for alihusnain03221704751@gmail.com'
                  : 'صرف مجاز ایڈمنسٹریٹر کے لیے ماڈریشن اور سسٹم کنٹرول'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="bg-stone-100 border-b border-stone-200 p-2 flex items-center gap-1 overflow-x-auto shrink-0">
          {adminTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeAdminTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveAdminTab(tab.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-stone-900 text-white shadow-sm'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {backupMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{backupMessage}</span>
            </div>
          )}

          {/* 1. OWNER CONTROL & INFRASTRUCTURE TAB */}
          {activeAdminTab === 'owner' && (
            <div className="space-y-6">
              {/* Ownership Card */}
              <div className="p-5 bg-gradient-to-br from-stone-900 to-stone-950 text-white rounded-2xl border border-stone-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] text-amber-400 uppercase tracking-widest font-mono block">
                      VERIFIED APPLICATION OWNER
                    </span>
                    <h4 className="font-bold text-base text-stone-100 font-mono">
                      alihusnain03221704751@gmail.com
                    </h4>
                    <p className="text-xs text-stone-400 mt-0.5">
                      {language === 'en'
                        ? 'Exclusive Super Administrator with irrevocable governance over app settings and deployment.'
                        : 'ایپ کا مجاز مالک اور بااختیار ایڈمنسٹریٹر'}
                    </p>
                  </div>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-xs font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>OWNER CONFIRMED</span>
                  </span>
                </div>

                {/* Infrastructure Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-stone-800 text-xs">
                  <div className="p-3 bg-stone-800/60 rounded-xl border border-stone-700/80">
                    <span className="text-stone-400 block text-[10px]">Cloud Run Dev App URL</span>
                    <a
                      href="https://ais-dev-3ifi6p5v3htdchfegr5ti2-93971271854.asia-east1.run.app"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-400 font-mono text-[11px] truncate flex items-center gap-1 hover:underline mt-0.5"
                    >
                      <span className="truncate">ais-dev-3ifi6p5v3htdchfegr5ti2-93971271854.asia-east1.run.app</span>
                      <ExternalLink className="w-3 h-3 shrink-0" />
                    </a>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-xl border border-stone-700/80">
                    <span className="text-stone-400 block text-[10px]">Preview Shared URL</span>
                    <a
                      href="https://ais-pre-3ifi6p5v3htdchfegr5ti2-93971271854.asia-east1.run.app"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-400 font-mono text-[11px] truncate flex items-center gap-1 hover:underline mt-0.5"
                    >
                      <span className="truncate">ais-pre-3ifi6p5v3htdchfegr5ti2-93971271854.asia-east1.run.app</span>
                      <ExternalLink className="w-3 h-3 shrink-0" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Security & Access Protection Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-stone-900">
                    <Key className="w-4 h-4 text-emerald-700" />
                    <span>API Secrets Protection</span>
                  </div>
                  <p className="text-stone-600 text-[11px] leading-relaxed">
                    Zero private API keys or database passwords are hardcoded in client-side code. All keys are isolated in backend environment variables.
                  </p>
                </div>

                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-stone-900">
                    <Database className="w-4 h-4 text-emerald-700" />
                    <span>Database & RBAC</span>
                  </div>
                  <p className="text-stone-600 text-[11px] leading-relaxed">
                    Ordinary users cannot alter application settings, view private user records, or modify verification queues without owner rights.
                  </p>
                </div>

                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-stone-900">
                    <ShieldAlert className="w-4 h-4 text-emerald-700" />
                    <span>No Transfer Guarantee</span>
                  </div>
                  <p className="text-stone-600 text-[11px] leading-relaxed">
                    No project transfer, deletion, or public release can occur without explicit, confirmed authorization from your master Google account.
                  </p>
                </div>
              </div>

              {/* Disaster Recovery & System Backup Controls */}
              <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-sm space-y-4">
                <div>
                  <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                    <Download className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'en' ? 'System Backup & Recovery (JSON Export / Import)' : 'سسٹم بیک اپ اور ڈیٹا ریکوری'}</span>
                  </h4>
                  <p className="text-xs text-stone-500 mt-0.5">
                    {language === 'en'
                      ? 'Safely export all application settings, bookmarks, and notification schedules to a local JSON file or restore from a previous backup.'
                      : 'تمام ترجیحات اور بک مارکس کی بیک اپ فائل محفوظ کریں یا سابقہ فائل سے بحال کریں۔'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={handleExportBackup}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>{language === 'en' ? 'Download JSON Backup' : 'بیک اپ فائل ڈاؤنلوڈ کریں'}</span>
                  </button>

                  <label className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold flex items-center gap-2 border border-stone-300 cursor-pointer transition-colors">
                    <Upload className="w-4 h-4 text-stone-600" />
                    <span>{language === 'en' ? 'Restore from Backup' : 'بیک اپ فائل بحال کریں'}</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImportBackup}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* 2. OVERVIEW TAB */}
          {activeAdminTab === 'overview' && (
            <div className="space-y-6">
              {/* Stat Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200">
                  <span className="text-xs text-stone-500 block">Total Users</span>
                  <span className="text-2xl font-bold font-mono text-stone-900">1 (Active)</span>
                  <span className="text-[10px] text-emerald-700 font-medium block mt-1">Google Session Verified</span>
                </div>
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200">
                  <span className="text-xs text-stone-500 block">Violations Queue</span>
                  <span className="text-2xl font-bold font-mono text-amber-700">0</span>
                  <span className="text-[10px] text-stone-500 font-medium block mt-1">Clean System</span>
                </div>
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200">
                  <span className="text-xs text-stone-500 block">Locked Phase 2</span>
                  <span className="text-2xl font-bold font-mono text-stone-900">6 Features</span>
                  <span className="text-[10px] text-amber-700 font-medium block mt-1">Protected Roadmap</span>
                </div>
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200">
                  <span className="text-xs text-stone-500 block">Security Posture</span>
                  <span className="text-2xl font-bold font-mono text-emerald-700">100% OK</span>
                  <span className="text-[10px] text-emerald-700 font-medium block mt-1">Zero Leaks</span>
                </div>
              </div>

              {/* Security Guardrails */}
              <div className="bg-stone-50 rounded-2xl p-5 border border-stone-200 space-y-2 text-xs text-stone-700">
                <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  Security Governance Summary:
                </h4>
                <ul className="list-disc list-inside space-y-1 text-stone-600 leading-relaxed text-[11px]">
                  <li>Only verified administrator emails ({ADMIN_EMAILS.join(', ')}) possess RBAC administration privileges.</li>
                  <li>Client-side code contains zero sensitive database credentials or GCP administrative keys.</li>
                  <li>Fake donations, dummy billing transactions, and mock user sessions are completely blocked.</li>
                </ul>
              </div>
            </div>
          )}

          {/* 3. MODERATION QUEUE */}
          {activeAdminTab === 'moderation' && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-950 space-y-1">
                <h4 className="font-bold text-amber-900 text-sm">
                  Islamic Video Moderation & 3-Warning Rule System:
                </h4>
                <p>
                  When the video portal launches in Phase 2, this audit queue records every verified complaint with timestamps, reviewer notes, and appeal records.
                </p>
              </div>

              <div className="border border-stone-200 rounded-2xl p-6 text-center text-stone-400 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="text-sm font-semibold text-stone-700">
                  Moderation queue is clean. Zero pending violations.
                </p>
                <p className="text-xs text-stone-400">
                  Videos feature is securely locked in the Phase 2 upgrade section.
                </p>
              </div>
            </div>
          )}

          {/* 4. TEACHERS VETTING */}
          {activeAdminTab === 'teachers' && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-1">
                <h4 className="font-bold text-emerald-900 text-sm">
                  Teacher Credentials Vetting & 5% Commission Ledger:
                </h4>
                <p>
                  Requires strict verification of Tajweed and Islamic Studies certificates prior to teaching authorization. Platform commission is fixed at exactly 5%.
                </p>
              </div>

              <div className="border border-stone-200 rounded-2xl p-6 text-center text-stone-400 space-y-2">
                <GraduationCap className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="text-sm font-semibold text-stone-700">
                  Teacher registration portal is pending Phase 2 authorization.
                </p>
              </div>
            </div>
          )}

          {/* 5. CHARITY AUDIT */}
          {activeAdminTab === 'charity' && (
            <div className="space-y-4">
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs text-stone-800 space-y-1">
                <h4 className="font-bold text-stone-900 text-sm">
                  Khidmat-e-Khalq Assistance Requests & Zakat Audit:
                </h4>
                <p>
                  All charity requests will be subject to thorough verification and approval by certified religious scholars to verify Zakat eligibility.
                </p>
              </div>

              <div className="border border-stone-200 rounded-2xl p-6 text-center text-stone-400 space-y-2">
                <HeartHandshake className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="text-sm font-semibold text-stone-700">
                  No active donation collection links are live.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
