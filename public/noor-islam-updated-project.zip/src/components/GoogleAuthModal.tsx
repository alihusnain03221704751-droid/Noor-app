import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { X, ShieldCheck, Key, AlertCircle, Info, Lock } from 'lucide-react';

interface GoogleAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoogleAuthModal: React.FC<GoogleAuthModalProps> = ({ isOpen, onClose }) => {
  const {
    clientId,
    isConfigured,
    setClientId,
    setAuthError,
    loginWithGoogleCredential,
    loginAsDemoUser,
    authError
  } = useAuth();
  const { t, language } = useLanguage();

  const [inputClientId, setInputClientId] = useState<string>(clientId || '');
  const [manualToken, setManualToken] = useState<string>('');
  const [showTokenInput, setShowTokenInput] = useState<boolean>(false);
  const [isLoadingAuth, setIsLoadingAuth] = useState<boolean>(false);
  const googleBtnContainerRef = useRef<HTMLDivElement>(null);

  // Initialize official Google Identity Services button if clientId is present
  useEffect(() => {
    if (!isOpen || !clientId) return;

    const timer = setTimeout(() => {
      const googleObj = (window as unknown as {
        google?: {
          accounts?: {
            id?: {
              initialize: (config: {
                client_id: string;
                callback: (res: { credential: string }) => void;
                auto_select?: boolean;
              }) => void;
              renderButton: (
                element: HTMLElement,
                options: {
                  theme?: string;
                  size?: string;
                  text?: string;
                  shape?: string;
                  width?: number;
                }
              ) => void;
            };
          };
        };
      }).google;

      if (googleObj?.accounts?.id && googleBtnContainerRef.current) {
        try {
          googleObj.accounts.id.initialize({
            client_id: clientId,
            callback: async (response: { credential: string }) => {
              if (response.credential) {
                setIsLoadingAuth(true);
                const success = await loginWithGoogleCredential(response.credential);
                setIsLoadingAuth(false);
                if (success) {
                  onClose();
                }
              }
            }
          });

          googleBtnContainerRef.current.innerHTML = '';
          googleObj.accounts.id.renderButton(googleBtnContainerRef.current, {
            theme: 'filled_black',
            size: 'large',
            text: 'signin_with',
            shape: 'rectangular',
            width: 280
          });
        } catch (err: unknown) {
          console.warn('Google Identity button render notice:', err);
          const errorMsg = err instanceof Error ? err.message : String(err);
          if (errorMsg.includes('client_id') || errorMsg.includes('invalid_client') || errorMsg.includes('project')) {
            setAuthError(
              'Error 401 (invalid_client / missing project id): Please verify your Web Client ID in Google Cloud Console or Firebase Authentication.'
            );
          }
        }
      }
    }, 150);

    return () => clearTimeout(timer);
  }, [isOpen, clientId, loginWithGoogleCredential, onClose]);

  if (!isOpen) return null;

  const handleSaveClientId = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputClientId.trim()) return;
    setClientId(inputClientId.trim());
  };

  const handleManualTokenSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualToken.trim()) return;
    setIsLoadingAuth(true);
    const ok = await loginWithGoogleCredential(manualToken.trim());
    setIsLoadingAuth(false);
    if (ok) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 overflow-hidden text-stone-800">
        {/* Header */}
        <div className="bg-stone-900 text-stone-100 p-6 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-emerald-400">
                {language === 'en' ? 'Google Sign-In' : 'Google سائن ان (Google Sign-In)'}
              </h3>
              <p className="text-xs text-stone-400">
                {language === 'en' ? 'Secure account profile & cloud preferences' : 'محفوظ اکاؤنٹ اور ذاتی ترجیحات'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {authError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs space-y-2">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold">{language === 'en' ? 'Authorization Error (Error 401: invalid_client)' : 'لاگ ان کی خرابی (Error 401: invalid_client)'}</p>
                  <p className="mt-0.5 text-rose-700">{authError}</p>
                </div>
              </div>

              <div className="bg-white/80 p-2.5 rounded-lg border border-rose-200 text-[11px] text-rose-900 space-y-1">
                <p className="font-bold text-rose-950">
                  {language === 'en' ? 'How to resolve this in Google Cloud / Firebase:' : 'اس خرابی کو حل کرنے کا آسان طریقہ:'}
                </p>
                <ol className="list-decimal list-inside space-y-0.5 text-stone-700">
                  <li>{language === 'en' ? 'Open Firebase Console > Authentication > Sign-in method.' : 'فائر بیس کنسول میں Authentication > Sign-in method کھولیں۔'}</li>
                  <li>{language === 'en' ? 'Ensure "Google" provider is Enabled and Project Support Email is selected.' : 'گوگل پرووائیڈر کو آن (Enable) کریں اور ای میل منتخب کریں۔'}</li>
                  <li>{language === 'en' ? 'Copy the Web Client ID (ending with .apps.googleusercontent.com) and paste it below.' : 'ویب کلائنٹ آئی ڈی کاپی کر کے نیچے محفوظ کریں۔'}</li>
                </ol>
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setClientId('');
                      setInputClientId('');
                    }}
                    className="text-emerald-700 hover:text-emerald-800 font-semibold underline text-[11px]"
                  >
                    {language === 'en' ? 'Reset / Re-enter Client ID now' : 'نئی کلائنٹ آئی ڈی درج کریں'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Actual Google Authentication Box */}
          {isConfigured ? (
            <div className="space-y-4 text-center">
              <p className="text-sm text-stone-600 leading-relaxed">
                {language === 'en'
                  ? 'Sign in securely with your Google account. Your bookmarks, custom city, and preferences will sync automatically.'
                  : 'براہ کرم اپنے مستند گوگل اکاؤنٹ سے سائن ان کریں۔ آپ کے بک مارکس اور ترجیحات محفوظ رہیں گی۔'}
              </p>

              <div className="flex flex-col items-center justify-center py-2 min-h-[50px]">
                {/* Official Google Identity Button Mount Target */}
                <div ref={googleBtnContainerRef} className="flex justify-center" />
                {isLoadingAuth && (
                  <p className="text-xs text-emerald-600 font-medium mt-2">
                    {language === 'en' ? 'Verifying authentication...' : 'توثیق کی جا رہی ہے (Verifying)...'}
                  </p>
                )}
              </div>

              <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
                <span className="flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-600" />
                  {language === 'en' ? 'SSL Encrypted & Secure Session' : 'SSL انکرپشن اور محفوظ سیشن'}
                </span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setClientId('')}
                    className="text-amber-700 hover:text-amber-800 underline text-[11px]"
                    title="Change Client ID or fix Error 401"
                  >
                    {language === 'en' ? 'Change Client ID' : 'کلائنٹ آئی ڈی تبدیل کریں'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowTokenInput(!showTokenInput)}
                    className="text-stone-500 hover:text-stone-800 underline text-[11px]"
                  >
                    {showTokenInput
                      ? (language === 'en' ? 'View standard button' : 'عام بٹن دیکھیں')
                      : (language === 'en' ? 'OAuth Token Mode' : 'OAuth ٹوکن موڈ')}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs space-y-2">
                <div className="flex items-center gap-2 font-semibold text-amber-950">
                  <Info className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>
                    {language === 'en' ? 'Google OAuth Client ID & Project Setup' : 'گوگل OAuth اور پراجیکٹ سیٹ اپ (Client ID Setup)'}
                  </span>
                </div>
                <p className="text-amber-900 leading-relaxed font-medium">
                  {language === 'en'
                    ? 'Fixing "Error 401: invalid_client / Client missing a project id":'
                    : '"Error 401: invalid_client / Client missing a project id" کا مکمل حل:'}
                </p>
                <div className="text-[11px] text-amber-800 space-y-1.5 leading-relaxed bg-amber-100/60 p-2.5 rounded-lg border border-amber-200">
                  <p className="font-semibold text-amber-950">
                    {language === 'en' ? 'Why this error happens:' : 'یہ خرابی کیوں آتی ہے:'}
                  </p>
                  <p>
                    {language === 'en'
                      ? '1. In Google Cloud / Firebase, the OAuth Client ID has not been created under an active Project, or the Web Client ID is missing.'
                      : '1. گوگل کلاؤڈ یا فائر بیس پروجیکٹ کے اندر درست OAuth 2.0 Web Client ID نہیں بنی یا پراجیکٹ تفویض نہیں ہے۔'}
                  </p>
                  <p>
                    {language === 'en'
                      ? '2. For Android / Web apps, Google Sign-In requires a "Web application" type OAuth Client ID (ending in .apps.googleusercontent.com) and Authorized JavaScript Origins.'
                      : '2. اینڈرائیڈ ویب ویو یا ویب کے لیے "Web application" کلائنٹ آئی ڈی درکار ہوتی ہے، اور اصل ڈومین مجاز (Authorized Origins) میں شامل ہونی چاہیے۔'}
                  </p>
                </div>
              </div>

              <form onSubmit={handleSaveClientId} className="space-y-3">
                <label className="block text-xs font-semibold text-stone-700">
                  {language === 'en' ? 'Enter Google OAuth Client ID:' : 'گوگل OAuth کلائنٹ آئی ڈی درج کریں:'}
                </label>
                <div className="relative">
                  <Key className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={inputClientId}
                    onChange={(e) => setInputClientId(e.target.value)}
                    placeholder="xxxxxxxxxxxx.apps.googleusercontent.com"
                    className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-stone-800"
                  />
                </div>
                <p className="text-[11px] text-stone-500">
                  {language === 'en' ? 'Or define in environment:' : 'یا ماحول میں'}{' '}
                  <code className="bg-stone-100 px-1 py-0.5 rounded text-emerald-700 font-mono">VITE_GOOGLE_CLIENT_ID</code>
                </p>
                <button
                  type="submit"
                  disabled={!inputClientId.trim()}
                  className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
                >
                  {language === 'en' ? 'Save Client ID & Enable Button' : 'کلائنٹ آئی ڈی محفوظ کریں اور بٹن چالو کریں'}
                </button>
              </form>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => setShowTokenInput(!showTokenInput)}
                  className="text-stone-500 hover:text-stone-800 underline text-xs"
                >
                  {language === 'en' ? 'Alternative: Paste Google ID Token (JWT)' : 'متبادل: دستی تصدیقی گوگل آئی ڈی ٹوکن (JWT) داخل کریں'}
                </button>
              </div>
            </div>
          )}

          {/* Optional Direct Token Validator for Google GIS JWT */}
          {showTokenInput && (
            <form onSubmit={handleManualTokenSubmit} className="pt-3 border-t border-stone-200 space-y-2">
              <label className="block text-[11px] font-semibold text-stone-600">
                Google Identity Services ID Token (JWT):
              </label>
              <textarea
                value={manualToken}
                onChange={(e) => setManualToken(e.target.value)}
                placeholder="eyJhbGciOiJSUzI1NiIs..."
                rows={2}
                className="w-full p-2 text-[10px] font-mono border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
              <button
                type="submit"
                disabled={!manualToken.trim() || isLoadingAuth}
                className="w-full py-1.5 px-3 bg-stone-800 hover:bg-stone-900 disabled:opacity-50 text-white text-xs rounded-lg font-medium"
              >
                {language === 'en' ? 'Validate Token & Sign In' : 'ٹوکن کی توثیق کریں اور لاگ ان ہوں'}
              </button>
            </form>
          )}

          {/* Quick Demo / Verification Logins for instant evaluation */}
          <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-900 text-[11px] uppercase tracking-wider">
                {language === 'en' ? 'Quick Test / Review Logins' : 'فوری ٹیسٹ اور جائزہ سیشنز'}
              </span>
              <span className="text-[10px] text-amber-700 font-mono bg-amber-100 px-1.5 py-0.5 rounded">
                One-Click
              </span>
            </div>
            <p className="text-[11px] text-stone-600 leading-normal">
              {language === 'en'
                ? 'Test Madrasa management, approvals, and permissions without needing an active Google Cloud API key.'
                : 'گوگل کلاؤڈ کلائنٹ آئی ڈی کے بغیر مدارس مینیجمنٹ اور ایڈمن اختیارات کا جائزہ لینے کے لیے لاگ ان کریں۔'}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  loginAsDemoUser('admin');
                  onClose();
                }}
                className="py-2 px-3 rounded-xl bg-stone-900 hover:bg-black text-amber-300 font-semibold text-[11px] text-center border border-amber-400/30 transition-all flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Super Admin (Ali Husnain)</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  loginAsDemoUser('member');
                  onClose();
                }}
                className="py-2 px-3 rounded-xl bg-white hover:bg-stone-100 text-stone-800 font-semibold text-[11px] text-center border border-stone-300 transition-all flex items-center justify-center gap-1.5"
              >
                <span>Member / Applicant</span>
              </button>
            </div>
          </div>

          {/* Privacy & Security Assurances */}
          <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200/60 text-[11px] text-stone-600 space-y-1.5">
            <p className="font-semibold text-stone-800 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              {language === 'en' ? 'Privacy & Data Protection:' : 'رازداری اور ڈیٹا کا تحفظ:'}
            </p>
            <ul className="list-disc list-inside space-y-1 pl-1 text-stone-500 leading-normal">
              <li>{language === 'en' ? 'Only standard profile data (name, email, avatar) is accessed.' : 'صرف بنیادی پروفائل معلومات (نام، ای میل، تصویر) استعمال ہوتی ہیں۔'}</li>
              <li>{language === 'en' ? 'Your password is never accessed; authentication is verified by Google.' : 'آپ کے پاس ورڈ تک کوئی رسائی نہیں ہوتی، گوگل خود تصدیق کرتا ہے۔'}</li>
              <li>{language === 'en' ? 'Upon logout, all session tokens are immediately revoked.' : 'لاگ آؤٹ پر تمام سیشن کوکیز اور ٹوکنز فوری حذف کر دیے جاتے ہیں۔'}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
