import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeOverview } from './components/HomeOverview';
import { PrayerTimesSection } from './components/PrayerTimesSection';
import { QuranSection } from './components/QuranSection';
import { NamazAzkaarSection } from './components/NamazAzkaarSection';
import { QiblaCompass } from './components/QiblaCompass';
import { FutureUpgradeSection } from './components/FutureUpgradeSection';
import { GoogleAuthModal } from './components/GoogleAuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { MadrasaSection } from './components/MadrasaSection';
import { MasajidSection } from './components/MasajidSection';
import { MadrasaProvider } from './context/MadrasaContext';
import { CITIES_LIST, calculatePrayerTimes } from './utils/prayerTimes';
import { CityOption, PrayerTimeData } from './types';

function HasanQuranApp() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedCity, setSelectedCity] = useState<CityOption>(() => {
    const saved = localStorage.getItem('noor_selected_city');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return CITIES_LIST[0]; // Lahore by default
  });

  const [juristicMethod, setJuristicMethod] = useState<'Hanafi' | 'Shafii'>(() => {
    const saved = localStorage.getItem('noor_juristic_method');
    return saved === 'Shafii' || saved === 'Hanafi' ? saved : 'Hanafi';
  });

  const [prayerTimesData, setPrayerTimesData] = useState<PrayerTimeData>(() =>
    calculatePrayerTimes(new Date(), selectedCity.lat, selectedCity.lng, 'Karachi', juristicMethod)
  );

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState<boolean>(false);

  // Recalculate prayer times every minute or when city/method changes
  useEffect(() => {
    localStorage.setItem('noor_selected_city', JSON.stringify(selectedCity));
    localStorage.setItem('noor_juristic_method', juristicMethod);
    const update = () => {
      setPrayerTimesData(calculatePrayerTimes(new Date(), selectedCity.lat, selectedCity.lng, 'Karachi', juristicMethod));
    };
    update();
    const interval = setInterval(update, 60000);
    return () => clearInterval(interval);
  }, [selectedCity, juristicMethod]);

  return (
    <div className="min-h-screen bg-warm-canvas text-stone-900 flex flex-col font-sans pb-22 md:pb-12 transition-colors">
      {/* Top Application Header matching Reference styling */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onOpenAdmin={() => setIsAdminModalOpen(true)}
        hijriFormatted={prayerTimesData.hijriDate.formatted}
        cityNameUrdu={selectedCity.nameUrdu}
        cityNameEn={selectedCity.name}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'home' && (
          <HomeOverview
            onTabChange={setActiveTab}
            onOpenAuth={() => setIsAuthModalOpen(true)}
            selectedCity={selectedCity}
            prayerTimesData={prayerTimesData}
          />
        )}

        {activeTab === 'prayer' && (
          <PrayerTimesSection
            onGoToQibla={() => setActiveTab('qibla')}
            selectedCity={selectedCity}
            onSelectCity={setSelectedCity}
            prayerTimesData={prayerTimesData}
            juristicMethod={juristicMethod}
            onSelectJuristicMethod={setJuristicMethod}
          />
        )}

        {activeTab === 'quran' && <QuranSection />}

        {activeTab === 'azkaar' && <NamazAzkaarSection />}

        {activeTab === 'qibla' && <QiblaCompass selectedCity={selectedCity} />}

        {activeTab === 'madrasas' && <MadrasaSection />}

        {activeTab === 'masajid' && <MasajidSection />}

        {activeTab === 'upgrade' && <FutureUpgradeSection />}
      </main>

      {/* Footer Branding & Disclaimer */}
      <footer className="border-t border-[#e5d8c3] bg-[#fbf5e7]/80 py-8 text-stone-600 text-xs text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          <span className="font-display italic font-bold text-lg text-stone-900">Hasan Quran</span>
          <span className="text-stone-400">·</span>
          <span className="font-urdu text-sm font-semibold text-[#264a39]">حسن قرآن</span>
        </div>
        <p className="font-urdu text-[11px] text-stone-600 max-w-md mx-auto px-4">
          مستند قرآنی متن اور احادیثِ نبویہ کے ساتھ ڈیزائن کردہ۔ جملہ حقوق محفوظ ہیں۔
        </p>
        <p className="text-[10px] text-stone-500 font-mono">
          Version 1.0 (Production Release) · Phase 2 Upgrades Reserved & Protected
        </p>
      </footer>

      {/* Mobile Bottom Navigation with 6 options including Home */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Google Sign-In Modal */}
      <GoogleAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* User Profile Modal */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        onOpenAdmin={() => setIsAdminModalOpen(true)}
      />

      {/* Admin Panel Modal */}
      <AdminPanelModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <MadrasaProvider>
          <HasanQuranApp />
        </MadrasaProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}
