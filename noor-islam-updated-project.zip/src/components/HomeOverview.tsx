import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { IslamicMotif } from './IslamicMotif';
import { IslamicAppIcon } from './IslamicAppIcon';
import {
  Clock,
  BookOpen,
  Heart,
  Compass,
  Lock,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Sun,
  Moon,
  Building2
} from 'lucide-react';
import { CityOption, PrayerTimeData } from '../types';

interface HomeOverviewProps {
  onTabChange: (tab: string) => void;
  onOpenAuth: () => void;
  selectedCity: CityOption;
  prayerTimesData: PrayerTimeData;
}

export const HomeOverview: React.FC<HomeOverviewProps> = ({
  onTabChange,
  onOpenAuth,
  selectedCity,
  prayerTimesData
}) => {
  const { t, language } = useLanguage();
  const { user, isAuthenticated } = useAuth();

  const nextPrayerName = language === 'en' ? prayerTimesData.nextPrayer.name : prayerTimesData.nextPrayer.nameUrdu;

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fade-in">
      {/* 1. HERO SPLASH CARD (Directly from Reference Screen 2 & Screen 1) */}
      <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-b from-[#fbf5e7] via-[#f7eee0] to-[#ecdcc4] border border-[#d9c5a5]/70 shadow-lg p-6 sm:p-8 text-stone-900">
        {/* Subtle decorative Islamic motifs */}
        <div className="absolute top-4 right-6 text-amber-700/30">
          <IslamicMotif variant="star-burst" className="w-10 h-10" />
        </div>
        <div className="absolute top-12 left-6 text-amber-700/25">
          <IslamicMotif variant="crescent" className="w-8 h-8" />
        </div>

        <div className="flex flex-col items-center text-center space-y-4 pt-2">
          {/* Crescent & Title in Reference font style */}
          <div className="w-10 h-10 rounded-full bg-amber-500/10 text-amber-800 flex items-center justify-center">
            <IslamicMotif variant="crescent" className="w-6 h-6 text-amber-800" />
          </div>

          <div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-stone-900 italic">
              Hasan Quran
            </h1>
            <p className="font-display text-base sm:text-lg text-stone-700 tracking-wide mt-1">
              {language === 'en' ? 'Hasan Quran - Your Daily Deen Companion' : 'حسن قرآن - آپ کا مستند دینی و روحانی رہنما'}
            </p>
          </div>

          {/* Mosque Silhouette / Illustration Header */}
          <div className="w-full max-w-md py-2 flex justify-center">
            <div className="w-full h-32 rounded-2xl bg-gradient-to-t from-emerald-900/15 via-amber-700/10 to-transparent flex items-end justify-center pb-2 relative overflow-hidden border border-amber-800/10">
              <IslamicMotif variant="dome" className="w-48 h-24 text-[#264a39]/80" />
            </div>
          </div>

          {/* Auth Action Buttons matching Reference (Get Started / Sign In) */}
          <div className="w-full max-w-sm space-y-2.5 pt-2">
            {!isAuthenticated ? (
              <>
                <button
                  onClick={() => onTabChange('prayer')}
                  className="w-full py-3.5 px-6 rounded-full bg-[#264a39] hover:bg-[#1e392c] text-white font-medium text-sm tracking-wide shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2"
                >
                  <span>{language === 'en' ? 'Get Started' : 'شروع کریں'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={onOpenAuth}
                  className="w-full py-3 px-6 rounded-full bg-white/80 hover:bg-white text-stone-800 font-medium text-sm border border-[#d9c5a5] shadow-xs transition-all active:scale-[0.99]"
                >
                  {language === 'en' ? 'Sign in with Google' : 'گوگل سے سائن ان کریں'}
                </button>
              </>
            ) : (
              <div className="p-3 bg-white/70 rounded-2xl border border-[#d9c5a5] flex items-center justify-between">
                <div className="flex items-center gap-2.5 text-left">
                  <div className="w-8 h-8 rounded-full bg-[#264a39] text-white flex items-center justify-center font-bold text-xs">
                    {user?.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-stone-900 block">{user?.name}</span>
                    <span className="text-[10px] text-stone-600 block">{user?.email}</span>
                  </div>
                </div>
                <button
                  onClick={() => onTabChange('prayer')}
                  className="px-3.5 py-1.5 rounded-full bg-[#264a39] text-white text-xs font-medium shadow-xs"
                >
                  {language === 'en' ? 'Open Dashboard' : 'ڈیش بورڈ'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. TODAY'S AYAH CARD (Deep Emerald Curved Card with Gold Accents matching Reference Screen 1) */}
      <div className="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-[#1b382b] via-[#244837] to-[#1c3a2d] text-white p-6 shadow-xl border border-emerald-800/40">
        <div className="absolute top-0 right-0 w-44 h-44 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-2 right-4 text-emerald-600/30">
          <IslamicMotif variant="star-burst" className="w-20 h-20" />
        </div>

        <div className="relative z-10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-widest text-amber-300 font-semibold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{language === 'en' ? "Today's Ayah" : 'آج کی قرآنی آیت'}</span>
            </span>
            <span className="text-[11px] text-stone-300 font-serif italic">
              {prayerTimesData.hijriDate.formatted}
            </span>
          </div>

          <div className="space-y-2">
            <p className="font-arabic text-xl sm:text-2xl text-amber-100 text-right leading-loose" dir="rtl">
              وَوَجَدَكَ ضَالًّا فَهَدَىٰ
            </p>
            <p className="font-display text-base sm:text-lg text-white font-medium italic">
              "{language === 'en' ? 'And He found you lost and guided you.' : 'اور آپ کو (راہِ حق کا) متلاشی پایا تو ہدایت فرمائی۔'}"
            </p>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-emerald-700/50">
            <span className="text-xs text-amber-300 font-mono font-medium">Quran 93:7 (Surah Ad-Duha)</span>
            <button
              onClick={() => onTabChange('quran')}
              className="px-3.5 py-1.5 rounded-full bg-white text-[#1b382b] hover:bg-amber-100 text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
            >
              <IslamicAppIcon type="quran" size="xs" />
              <span>{language === 'en' ? 'Reflect / Recite' : 'تلاوت کریں'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. QUICK ACCESS 4-GRID (Prayer, Habits, Umrah, Planner from Reference Screen 1) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="font-display text-xl font-bold text-stone-900 tracking-tight">
            {language === 'en' ? 'Quick Access' : 'فوری رسائی'}
          </h2>
          <span className="text-xs text-stone-500 font-medium">
            {language === 'en' ? `Location: ${selectedCity.name}` : `مقام: ${selectedCity.nameUrdu}`}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-3.5">
          {/* Card 1: Prayer Times */}
          <button
            onClick={() => onTabChange('prayer')}
            className="p-4 rounded-2xl bg-white/90 hover:bg-white border border-[#e5d8c3] hover:border-[#264a39]/40 shadow-sm transition-all text-center flex flex-col items-center justify-center space-y-2 group"
          >
            <div className="w-13 h-13 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform relative">
              <IslamicAppIcon type="prayer" size="custom" className="w-12 h-12 shadow-md ring-2 ring-emerald-500/30" withGlow={true} />
            </div>
            <div>
              <span className="text-sm font-bold text-stone-900 block font-display">
                {t('nav_prayers')}
              </span>
              <span className="text-[10px] text-stone-500 block font-mono">
                {nextPrayerName}: {prayerTimesData.nextPrayer.time}
              </span>
            </div>
          </button>

          {/* Card 2: Habits & Azkaar */}
          <button
            onClick={() => onTabChange('azkaar')}
            className="p-4 rounded-2xl bg-white/90 hover:bg-white border border-[#e5d8c3] hover:border-[#264a39]/40 shadow-sm transition-all text-center flex flex-col items-center justify-center space-y-2 group"
          >
            <div className="w-13 h-13 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform relative">
              <IslamicAppIcon type="azkaar" size="custom" className="w-12 h-12 shadow-md ring-2 ring-emerald-500/30" withGlow={true} />
            </div>
            <div>
              <span className="text-sm font-bold text-stone-900 block font-display">
                {language === 'en' ? 'Habits & Dhikr' : 'اذکار و عادات'}
              </span>
              <span className="text-[10px] text-stone-500 block font-mono">
                {language === 'en' ? 'Daily Counter' : 'روزانہ تسبیح'}
              </span>
            </div>
          </button>

          {/* Card 3: Holy Quran (16-Line & Translation) */}
          <button
            onClick={() => onTabChange('quran')}
            className="p-4 rounded-2xl bg-white/90 hover:bg-white border border-[#e5d8c3] hover:border-[#264a39]/40 shadow-sm transition-all text-center flex flex-col items-center justify-center space-y-2 group"
          >
            <div className="w-13 h-13 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform relative">
              <IslamicAppIcon type="quran" size="custom" className="w-12 h-12 shadow-md ring-2 ring-emerald-500/30" withGlow={true} />
            </div>
            <div>
              <span className="text-sm font-bold text-stone-900 block font-display">
                {t('nav_quran')}
              </span>
              <span className="text-[10px] text-stone-500 block">
                {language === 'en' ? '16-Line & Urdu' : '۱۶ سطری و ترجمہ'}
              </span>
            </div>
          </button>

          {/* Card 4: Qibla & Direction */}
          <button
            onClick={() => onTabChange('qibla')}
            className="p-4 rounded-2xl bg-white/90 hover:bg-white border border-[#e5d8c3] hover:border-[#264a39]/40 shadow-sm transition-all text-center flex flex-col items-center justify-center space-y-2 group"
          >
            <div className="w-13 h-13 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform relative">
              <IslamicAppIcon type="qibla" size="custom" className="w-12 h-12 shadow-md ring-2 ring-emerald-500/30" withGlow={true} />
            </div>
            <div>
              <span className="text-sm font-bold text-stone-900 block font-display">
                {t('nav_qibla')}
              </span>
              <span className="text-[10px] text-stone-500 block font-mono">
                {language === 'en' ? 'Kaaba Compass' : 'سمتِ قبلہ'}
              </span>
            </div>
          </button>

          {/* Card 5: Madrasa Directory & Admissions */}
          <button
            onClick={() => onTabChange('madrasas')}
            className="p-4 rounded-2xl bg-white/90 hover:bg-white border border-[#e5d8c3] hover:border-[#264a39]/40 shadow-sm transition-all text-center flex flex-col items-center justify-center space-y-2 group cursor-pointer"
          >
            <div className="w-13 h-13 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform relative">
              <IslamicAppIcon type="madrasa" size="custom" className="w-12 h-12 shadow-md ring-2 ring-emerald-500/30" withGlow={true} />
            </div>
            <div>
              <span className="text-sm font-bold text-stone-900 block font-display">
                {t('nav_madrasas')}
              </span>
              <span className="text-[10px] text-stone-500 block font-mono">
                {language === 'en' ? 'Seminaries' : 'مدارس و داخلہ جات'}
              </span>
            </div>
          </button>

          {/* Card 6: Masajid Near Me */}
          <button
            onClick={() => onTabChange('masajid')}
            className="p-4 rounded-2xl bg-white/90 hover:bg-white border border-[#e5d8c3] hover:border-[#264a39]/40 shadow-sm transition-all text-center flex flex-col items-center justify-center space-y-2 group cursor-pointer"
          >
            <div className="w-13 h-13 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform relative">
              <IslamicAppIcon type="masajid" size="custom" className="w-12 h-12 shadow-md ring-2 ring-emerald-500/30" withGlow={true} />
            </div>
            <div>
              <span className="text-sm font-bold text-stone-900 block font-display">
                {t('nav_masajid')}
              </span>
              <span className="text-[10px] text-stone-500 block font-mono">
                {language === 'en' ? 'Live Map & GPS' : 'قریبی مساجد'}
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* 4. RAMADAN & FASTING PLANNER CARD (Directly from Reference Screen 6) */}
      <div className="rounded-[28px] bg-gradient-to-br from-[#faf4e6] via-[#f5ebda] to-[#ede0cc] border border-[#d9c5a5] p-6 shadow-md relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-200/80 text-amber-950 font-bold text-[10px] border border-amber-300">
                {language === 'en' ? 'RAMADAN & FASTING' : 'رمضان المبارک اور روزے کے اوقات'}
              </span>
              <span className="text-xs text-stone-500 font-mono">
                {selectedCity.name}
              </span>
            </div>
            <h3 className="font-display text-2xl font-bold text-stone-900">
              {language === 'en' ? 'Ramadan Planner' : 'رمضان و روزہ پلانر'}
            </h3>
            <p className="font-display italic text-sm text-stone-700">
              "{language === 'en' ? 'Ya Allah, accept my fast.' : 'یا اللہ، ہمارے روزے اور عبادات قبول فرما۔'}"
            </p>
          </div>

          {/* Suhoor & Iftar Times Pill Cards */}
          <div className="flex items-center gap-3">
            <div className="bg-white/80 rounded-2xl p-3 border border-[#d9c5a5] text-center min-w-[100px]">
              <span className="text-[10px] uppercase font-bold text-stone-500 block">
                {language === 'en' ? 'Suhoor' : 'سحری ختم'}
              </span>
              <span className="font-mono text-base font-bold text-stone-900 block">
                {prayerTimesData.fajr}
              </span>
            </div>

            <div className="bg-white/80 rounded-2xl p-3 border border-[#d9c5a5] text-center min-w-[100px]">
              <span className="text-[10px] uppercase font-bold text-stone-500 block">
                {language === 'en' ? 'Iftar' : 'افطار وقت'}
              </span>
              <span className="font-mono text-base font-bold text-[#264a39] block">
                {prayerTimesData.maghrib}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 5. FUTURE UPGRADES & KHIDMAT-E-KHALQ PREVIEW (Screen 5 Umrah Savings / Welfare from Reference) */}
      <div className="rounded-[28px] bg-white border border-[#e5d8c3] p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-100/70 text-amber-900 flex items-center justify-center font-bold text-xl shrink-0">
            🕋
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-semibold">
                PHASE 2 UPGRADE
              </span>
              <span className="text-xs text-stone-500">6 Protected Modules</span>
            </div>
            <h4 className="font-display text-lg font-bold text-stone-900 mt-0.5">
              {language === 'en' ? 'Sadqa, Zakat, Fitrana & Welfare Roadmap' : 'صدقہ، زکوٰۃ، فطرانہ اور فلاحی روڈ میپ'}
            </h4>
            <p className="text-xs text-stone-600">
              {language === 'en' ? 'Explore all future locked features & verified charity guidelines.' : 'تمام ۶ محفوظ فیچرز اور شفاف شرعی رہنمائی دیکھیں۔'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onTabChange('upgrade')}
          className="px-4 py-2.5 rounded-full bg-[#264a39] hover:bg-[#1e392c] text-white text-xs font-semibold shadow-xs flex items-center justify-center gap-2 whitespace-nowrap transition-colors"
        >
          <span>{language === 'en' ? 'View Locked Roadmap' : 'محفوظ فیچرز دیکھیں'}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
