import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Home, Lock } from 'lucide-react';
import { IslamicAppIcon, IslamicIconType } from './IslamicAppIcon';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

interface NavTabItem {
  id: string;
  label: string;
  islamicIcon?: IslamicIconType;
  fallbackIcon?: React.ElementType;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const { t } = useLanguage();

  const tabs: NavTabItem[] = [
    { id: 'home', label: t('nav_home') || 'Home', fallbackIcon: Home },
    { id: 'prayer', label: t('nav_prayers'), islamicIcon: 'prayer' },
    { id: 'quran', label: t('nav_quran'), islamicIcon: 'quran' },
    { id: 'azkaar', label: t('nav_azkaar'), islamicIcon: 'azkaar' },
    { id: 'qibla', label: t('nav_qibla'), islamicIcon: 'qibla' },
    { id: 'madrasas', label: t('nav_madrasas') || 'Madrasas', islamicIcon: 'madrasa' },
    { id: 'masajid', label: t('nav_masajid') || 'Masajid', islamicIcon: 'masajid' },
    { id: 'upgrade', label: t('nav_future'), fallbackIcon: Lock }
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#fbf5e7]/95 backdrop-blur-md border-t border-[#e5d8c3] shadow-lg safe-area-pb">
      <div className="grid grid-cols-8 h-16 px-0.5">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const FallbackIcon = tab.fallbackIcon;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-1 transition-all ${
                isActive
                  ? 'text-[#264a39] font-bold'
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <div className={`p-1 rounded-full transition-transform ${isActive ? 'scale-110' : ''}`}>
                {tab.islamicIcon ? (
                  <IslamicAppIcon
                    type={tab.islamicIcon}
                    size="sm"
                    withGlow={isActive}
                    className={isActive ? 'ring-2 ring-emerald-500/50 shadow-md' : 'opacity-85 hover:opacity-100'}
                  />
                ) : FallbackIcon ? (
                  <div className={`p-1 rounded-full ${isActive ? 'bg-[#264a39]/15 text-[#264a39]' : 'text-stone-500'}`}>
                    <FallbackIcon className={`w-4 h-4 sm:w-5 sm:h-5 ${isActive ? 'stroke-[2.5]' : ''}`} />
                  </div>
                ) : null}
              </div>
              <span className={`text-[9px] mt-0.5 leading-tight text-center truncate max-w-[55px] ${isActive ? 'font-bold text-[#264a39]' : 'font-medium'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
