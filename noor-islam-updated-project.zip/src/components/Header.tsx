import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { LanguageSelector } from './LanguageSelector';
import { IslamicMotif } from './IslamicMotif';
import { IslamicAppIcon } from './IslamicAppIcon';
import {
  Compass,
  ShieldCheck,
  User as UserIcon,
  LogIn,
  Lock,
  Clock,
  BookOpen,
  Heart,
  Home,
  Building2
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenAdmin: () => void;
  hijriFormatted: string;
  cityNameUrdu: string;
  cityNameEn: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  onOpenAuth,
  onOpenProfile,
  onOpenAdmin,
  hijriFormatted,
  cityNameUrdu,
  cityNameEn
}) => {
  const { user, isAuthenticated } = useAuth();
  const { t, language } = useLanguage();

  const displayCity = language === 'en' ? cityNameEn : cityNameUrdu;

  return (
    <header className="sticky top-0 z-40 bg-[#fbf5e7]/90 text-stone-900 backdrop-blur-md border-b border-[#e5d8c3] shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Brand Logo & Title with Reference Serif Font */}
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => onTabChange('home')}>
            <IslamicAppIcon type="quran" size="md" withGlow={true} className="group-hover:scale-105 transition-transform shadow-md" />
            <div>
              <div className="flex items-baseline gap-2">
                <span className="font-display font-bold italic tracking-tight text-2xl sm:text-3xl text-stone-900">
                  Hasan Quran
                </span>
                <span className="text-stone-500 font-display text-xs hidden sm:inline tracking-wider">
                  {language === 'en' ? 'Authentic Islamic Companion' : 'حسن قرآن'}
                </span>
              </div>
              <div className="text-stone-500 text-[11px] flex items-center gap-1.5 font-medium">
                <span className="text-[#264a39] font-semibold">{displayCity}</span>
                <span aria-hidden="true" className="text-stone-400">·</span>
                <span className="text-amber-800 font-serif italic">{hijriFormatted}</span>
              </div>
            </div>
          </div>

          {/* Desktop Nav Items with Warm Sand / Deep Sage styling */}
          <nav className="hidden md:flex items-center gap-1.5">
            <button
              onClick={() => onTabChange('home')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'home'
                  ? 'bg-[#264a39] text-white shadow-xs font-bold'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              <Home className="w-3.5 h-3.5" />
              <span>{t('nav_home')}</span>
            </button>
            <button
              onClick={() => onTabChange('prayer')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'prayer'
                  ? 'bg-[#264a39] text-white shadow-xs font-bold'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              <IslamicAppIcon type="prayer" size="xs" />
              <span>{t('nav_prayers')}</span>
            </button>
            <button
              onClick={() => onTabChange('quran')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'quran'
                  ? 'bg-[#264a39] text-white shadow-xs font-bold'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              <IslamicAppIcon type="quran" size="xs" />
              <span>{t('nav_quran')}</span>
            </button>
            <button
              onClick={() => onTabChange('azkaar')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'azkaar'
                  ? 'bg-[#264a39] text-white shadow-xs font-bold'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              <IslamicAppIcon type="azkaar" size="xs" />
              <span>{t('nav_azkaar')}</span>
            </button>
            <button
              onClick={() => onTabChange('qibla')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'qibla'
                  ? 'bg-[#264a39] text-white shadow-xs font-bold'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              <IslamicAppIcon type="qibla" size="xs" />
              <span>{t('nav_qibla')}</span>
            </button>
            <button
              onClick={() => onTabChange('madrasas')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'madrasas'
                  ? 'bg-[#264a39] text-white shadow-xs font-bold'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              <IslamicAppIcon type="madrasa" size="xs" />
              <span>{t('nav_madrasas')}</span>
            </button>
            <button
              onClick={() => onTabChange('masajid')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'masajid'
                  ? 'bg-[#264a39] text-white shadow-xs font-bold'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              <IslamicAppIcon type="masajid" size="xs" />
              <span>{t('nav_masajid')}</span>
            </button>
            <button
              onClick={() => onTabChange('upgrade')}
              className={`px-3 py-2 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 ${
                activeTab === 'upgrade'
                  ? 'bg-amber-800 text-white shadow-xs font-bold'
                  : 'text-amber-900/90 hover:text-amber-950 hover:bg-amber-100/50'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{t('nav_future')}</span>
            </button>
          </nav>

          {/* User, Language Selector & Admin Actions */}
          <div className="flex items-center gap-2">
            {/* Language Switcher */}
            <LanguageSelector />

            {isAuthenticated && user?.role === 'admin' && (
              <button
                onClick={onOpenAdmin}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-900 border border-amber-600/30 hover:bg-amber-500/25 transition-colors"
                title="Admin Control Center"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
                <span>{t('admin_panel')}</span>
              </button>
            )}

            {isAuthenticated && user ? (
              <button
                onClick={onOpenProfile}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-[#e5d8c3] hover:border-[#264a39] transition-colors text-xs text-stone-800 shadow-xs"
              >
                {user.picture ? (
                  <img src={user.picture} alt={user.name} className="w-6 h-6 rounded-full object-cover" />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-[#264a39] text-white flex items-center justify-center font-bold text-xs">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                )}
                <span className="hidden sm:inline max-w-[100px] truncate font-medium">{user.name}</span>
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#264a39] hover:bg-[#1e392c] text-white text-xs font-semibold shadow-xs transition-colors"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{t('google_signin')}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
